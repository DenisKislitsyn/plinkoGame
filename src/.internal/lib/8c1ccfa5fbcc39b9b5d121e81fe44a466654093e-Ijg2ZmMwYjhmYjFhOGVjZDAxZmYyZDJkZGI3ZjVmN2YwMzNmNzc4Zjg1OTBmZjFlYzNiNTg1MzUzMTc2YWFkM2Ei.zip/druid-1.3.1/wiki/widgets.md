# Widgets

Widgets are reusable UI components that simplify the creation and management of user interfaces in your game.

## What is widget

Before widgets, there were "custom components". Widgets replace custom components. Basically, they're the same thing, with the only difference being how they're initialized.

Let's see a basic custom component template:

```lua
local component = require("druid.component")

---@class my_component: druid.component
local M = component.create("my_component")

function M:init(template, nodes)
    self:set_template(template)
    self:set_nodes(nodes)
    self.druid = self:get_druid()

    self.druid:new_button("button_node_name", self.on_click)
end

function M:on_click()
    print("Current output string: " .. self.output_string)
end

function M:set_output_string(output_string)
    self.output_string = output_string
end
```

Basic components are created with the `druid:new()` function:

```lua
local template = "my_component" -- The template name on GUI scene, if nil will take nodes directly by gui.get_node()
local nodes = gui.clone_tree(gui.get_node("my_component/root")) -- We can clone component nodes and init over cloned nodes

local my_component = druid:new("my_component", template, nodes)
my_component:set_output_string("Hello world!")
```

Now, let's see how to do it with widgets:

```lua
---@type my_widget: druid.widget
local M = {}

function M:init()
    self.druid:new_button("button_node_name", self.on_click)
    self.output_string = ""
end

function M:on_click()
    print("Current output string: " .. self.output_string)
end

function M:set_output_string(output_string)
    self.output_string = output_string
end

return M
```

That's all! The same functionality but without any boilerplate code, just a Lua table. The Druid instance, templates and nodes are already created and available.

And you can create your own widgets like this:

```lua
local druid = require("druid.druid")
local my_widget = require("widgets.my_widget.my_widget")

function init(self)
    self.druid = druid.new(self)
    local template_id = "my_widget" -- If using a GUI template, set a template id, otherwise set nil
    local nodes = nil -- If nodes are cloned with gui.clone_tree(), set a nodes table, otherwise set nil
    self.my_widget = self.druid:new_widget(my_widget, template_id, nodes)
    self.my_widget:set_output_string("Hello world!")
end
```

So now creating UI components with widgets is much easier and cleaner than using custom components.

## Create a new widget

Let's start from the beginning. Widgets usually consist of 2 parts:

1. GUI scene
2. Widget Lua module

Make a GUI scene of your widget (user portrait avatar panel, shop window, game panel menu, etc). Design it as you wish, but it's recommended to add one `root` node with the id `root` and make all your other nodes children of this node. This makes working with the widget much easier. Also ofter this root will represent the widget size, so it's recommended to set it's size to the desired size of the widget.

Let's create a new widget by creating a new file next to our GUI scene file:

```lua
-- my_widget.lua
local M = {}

function M:init()
    self.root = self:get_node("root")
    self.button = self.druid:new_button("button_open", self.open_widget, self)
end

function M:open_widget()
    print("Open widget pressed")
end

return M
```

That's the basic creation process. Now we have a widget where we access the root node and use the "button_open" node as a button.

Widget modules also support lifecycle callbacks:

```lua
-- Called before widget is removed by `druid:remove(widget)` call or on `druid:final()` call
function M:on_remove() end

-- Called every frame update
function M:update(dt) end

-- Called when input is dispatched to widget. Return true to consume input
function M:on_input(action_id, action) return false end

-- Called on script message
function M:on_message(message_id, message, sender) end

-- Called on `druid.on_language_change` call
function M:on_language_change() end

-- Called when layout has changed
function M:on_layout_change() end

-- Called when window is resized
function M:on_window_resized() end

-- Called when input was already consumed by a higher-priority component
function M:on_input_interrupt() end

-- Called when widget lost focus
function M:on_focus_lost() end

-- Called when widget gained focus
function M:on_focus_gained() end
```

You can define only callbacks you need. Druid will call them automatically when corresponding events happen.

Additional `druid:new_widget(widget, template, nodes, ...)` arguments are forwarded to `M:init(...)`:

```lua
local M = {}

function M:init(user_id, options)
    self.user_id = user_id
    self.options = options
end

return M
```

```lua
self.profile_widget = self.druid:new_widget(profile_widget, "profile_widget", nil, "42", {
    show_badges = true
})
```

Now, let's create a widget inside your game scene.

Place a widget (GUI template) on your main scene. Then import Druid and create a new widget instance using this GUI template placed on the scene:

```lua
local druid = require("druid.druid")
local my_widget = require("widgets.my_widget.my_widget")

function init(self)
    self.druid = druid.new(self)
    self.my_widget = self.druid:new_widget(my_widget, "my_widget")

    -- In case we want to clone it and use several times we can pass the nodes table
    local array_of_widgets = {}
    for index = 1, 10 do
        -- Instead of manual gui.clone_tree() call, we can pass a node_id to clone from as the third argument
        local widget = self.druid:new_widget(my_widget, "my_widget", "root")
        table.insert(array_of_widgets, widget)
    end
end
```


## Using Widgets without GUI templates

It's a possible to use widgets without GUI templates. This widget can pick nodes from the parent instance.

```lua
-- my_widget.lua
local event = require("event.event")

local M = {}

function M:init()
    self.on_close = event.create()
    -- Since we have no template prefix to add in paths, it will pick nodes from the parent instance directly
    self.druid:new_hotkey("key_backspace", self.on_close)
end

return M
```

```lua
-- gui_script
local druid = require("druid.druid")
local my_widget = require("widgets.my_widget.my_widget")

local function on_close()
    print("Widget closed")
end

function init(self)
    self.druid = druid.new(self)
    self.my_widget = self.druid:new_widget(my_widget)
    self.my_widget.on_close:subscribe(on_close, self)
end
```


## Create Druid Widget Editor Script

Druid provides an editor script to assist you in creating Lua files for your GUI scenes. You can find the commands under the menu `Edit -> Create Druid Widget` when working with *.gui scenes.

This script will create a new widget lua file with the same name and basic template for the widget.

The Druid provides two templates:

- `/druid/templates/widget.lua.template` - Minimal template for the widget.
- `/druid/templates/widget_full.lua.template` - Full template for the widget.

You can change the path to the template in the `[Druid] Settings` option in the `Edit` menu.


## Creating GO widgets without *.gui_script

You can create Druid widgets from a game object script. This allows you to use widgets without creating dedicated `gui_script` files for each one.

For the GUI file you want to use as a widget, set its `gui_script` to `druid_widget.gui_script`.
When you call `druid.get_widget(widget, gui_url)` in a game object script, Druid creates a widget proxy with bindings for all top-level widget functions.

In some setups, you cannot create a widget immediately in `init(self)`, because the GUI component with `druid_widget.gui_script` may not be initialized yet.
In this case, defer widget creation to a later step (for example, via `msg.post` and `on_message`):

```lua
-- your_game_object.script
local druid = require("druid.druid")
local my_widget = require("widgets.my_widget.my_widget") -- Your widget module

function init(self)
    msg.post(".", "late_init")
end

local function on_event(self)
    print("Widget event happened")
end

function on_message(self, message_id, message, sender)
    if message_id == hash("late_init") then
        local gui_url = msg.url(nil, nil, "go_widget")
        self.go_widget = druid.get_widget(my_widget, gui_url)
        self.go_widget:play_animation()
        self.go_widget:set_position(go.get_position())
        self.go_widget.on_event:subscribe(on_event, self)
    end
end
```

This feature is called `GO Widgets`, and it is more advanced. Important notes:

- All top-level functions are wrapped with `event`, so they can be called from a GO script.
- Nested widget functions are not exposed.
- Top-level events are also available from a GO script.
- You cannot directly use `gui.*` functions on widget nodes from the GO script. Use widget API functions instead.

You can also pass params to a widget via `druid.get_widget(widget, gui_url, [params])`.

```lua
local my_widget = require("widgets.my_widget.my_widget")

function init(self)
    msg.post(".", "late_init")
end

function on_message(self, message_id, message, sender)
    if message_id == hash("late_init") then
        local gui_url = msg.url(nil, nil, "go_widget")
        self.go_widget = druid.get_widget(my_widget, gui_url, {
            show_badges = true
        })
    end
end
```

```lua
-- my_widget.lua
local M = {}

function M:init(params)
    self.show_badges = params.show_badges
end
```

If the widget nodes are placed inside a GUI template, pass the template name as the last argument:
`druid.get_widget(widget, gui_url, [params], [template])`. It is used to resolve the widget nodes, the same way as
in `druid:new_widget(widget_class, template, nodes, params)`.

```lua
function on_message(self, message_id, message, sender)
    if message_id == hash("late_init") then
        local gui_url = msg.url(nil, nil, "go_widget")
        self.go_widget = druid.get_widget(my_widget, gui_url, nil, "my_widget_template")
    end
end
```
